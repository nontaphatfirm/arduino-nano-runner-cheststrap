// เรียกใช้ไลบรารีสำหรับอุปกรณ์ Modulino
#include "Arduino_Modulino.h"
// สร้างอ็อบเจ็กต์สำหรับควบคุม Buzzer
ModulinoBuzzer buzzer;
// กำหนดค่าความถี่ของเสียง (หน่วย Hz)
// 440 Hz คือเสียงโน้ต A มาตรฐาน
int frequency = 220;
// กำหนดระยะเวลาเล่นเสียง (หน่วยมิลลิวินาที)
// 1000 ms = 1 วินาที
int duration = 1500;
void setup(){
  // เริ่มต้นระบบ Modulino
  Modulino.begin();
  // เริ่มต้นการทำงานของ Buzzer
  buzzer.begin();
}
void loop(){
  // สั่งให้ Buzzer ส่งเสียงตามความถี่และเวลาที่กำหนด
  buzzer.tone(frequency, duration);
  // หน่วงเวลา 1 วินาที
  delay(1000);
  // สั่งหยุดเสียง (ตั้งค่า frequency = 0)
  buzzer.tone(0, duration);
  // หน่วงเวลา 1 วินาทีก่อนเริ่มรอบใหม่
  delay(1000);
}
