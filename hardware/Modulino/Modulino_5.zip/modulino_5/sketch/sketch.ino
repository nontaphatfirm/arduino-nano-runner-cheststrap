// เรียกใช้ไลบรารีสำหรับควบคุมอุปกรณ์ Modulino
#include "Arduino_Modulino.h"
// เรียกใช้ไลบรารี RouterBridge (ใช้กับ UNO Q สำหรับ Monitor.print)
#include "Arduino_RouterBridge.h"
// สร้างอ็อบเจ็กต์สำหรับควบคุม Modulino Knob (Rotary Encoder)
ModulinoKnob knob;

void setup() {
  // เริ่มต้นการสื่อสารกับ Monitor (แสดงผลบนคอมพิวเตอร์)
  Monitor.begin();
  // เริ่มต้นระบบ Modulino (เตรียมการสื่อสาร I2C)
  Modulino.begin();
  // เริ่มต้นโมดูล Knob
  knob.begin();
}

void loop(){
  // อ่านค่าตำแหน่งปัจจุบันของ Knob
  // ค่าจะเพิ่มหรือลดตามการหมุน
  int position = knob.get();
  // ตรวจสอบว่าปุ่มกดบน Knob ถูกกดอยู่หรือไม่
  bool click = knob.isPressed();
  // แสดงข้อความบอกตำแหน่งปัจจุบัน
  // Monitor.print("ตำแหน่งปัจจุบันคือ : ");
  Monitor.println(position);
  // ถ้ามีการกดปุ่มบน Knob
  if(click){
    Monitor.println("มีการกดคลิก!");
  }
}
