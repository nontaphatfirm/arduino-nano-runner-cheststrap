
#include "Arduino_RouterBridge.h" // เรียกใช้ไลบรารีสำหรับระบบ RouterBridge เพื่อใช้กับคำสั่ง Monitor
#include "Arduino_Modulino.h" // เรียกใช้ไลบรารีสำหรับควบคุมอุปกรณ์ตระกูล Modulino
#include "Button2.h" // เรียกใช้ไลบรารี Button2 สำหรับจัดการ event การกดปุ่มหลายรูปแบบ

Button2 button; // สร้างอ็อบเจ็กต์ button สำหรับจัดการ event ปุ่ม
ModulinoButtons modulino_buttons; // สร้างอ็อบเจ็กต์สำหรับควบคุม Modulino Buttons
String msg; // ตัวแปรเก็บข้อความสำหรับแสดงผล

void setup() {
  Monitor.begin();// เริ่มต้นคำสั่ง Monitor
  Modulino.begin();// เริ่มต้นโมดูล Modulino
  modulino_buttons.begin();// เริ่มต้นโมดูลปุ่ม
  // ตั้งค่า debounce time = 35 ms (กันสัญญาณสั่นจากปุ่ม)
  button.setDebounceTime(35);
  // กำหนดฟังก์ชันสำหรับอ่านสถานะปุ่ม (ใช้แทน digitalRead)
  button.setButtonStateFunction(button0StateHandler);
  // กำหนด handler สำหรับคลิกครั้งเดียว
  button.setClickHandler(handler);
  // กำหนด handler สำหรับดับเบิ้ลคลิก
  button.setDoubleClickHandler(handler);
  // กำหนด handler สำหรับทริปเปิ้ลคลิก
  button.setTripleClickHandler(handler);
  // กำหนด handler สำหรับกดค้าง (long click)
  button.setLongClickHandler(handler);
  // เริ่มต้นใช้งานปุ่มแบบ virtual pin
  button.begin(BTN_VIRTUAL_PIN);
}

void loop() {
  // ต้องเรียก loop() ของ Button2 ตลอดเวลา
  // เพื่อให้ระบบตรวจจับ event ได้
  button.loop();
}

// ฟังก์ชันนี้ใช้ให้ Button2 อ่านสถานะปุ่มจาก Modulino แทนการอ่าน GPIO ปกติ
uint8_t button0StateHandler() {
  modulino_buttons.update();// อัปเดตข้อมูลล่าสุดจากโมดูลปุ่ม
  // ถ้าปุ่มหมายเลข 0 ถูกกด → ส่งค่า LOW
  // ถ้าไม่ถูกกด → ส่งค่า HIGH
  // (Button2 ใช้ logic แบบ active LOW)
  return modulino_buttons.isPressed(0) ? LOW : HIGH;
}
// ฟังก์ชัน handler จะถูกเรียกเมื่อเกิด event การกดปุ่ม
void handler(Button2& btn) {
  String msg_0 = "";// ตัวแปรเก็บประเภทของการกด
  // ตรวจสอบชนิดของ event (คลิก, ดับเบิ้ลคลิก ฯลฯ)
  switch (btn.getType()) {
    case single_click:
      msg_0 = "กดคลิก ";
      break;
    case double_click:
      msg_0 = "ดับเบิ้ลคลิก ";
      break;
    case triple_click:
      msg_0 = "ทริปเปิ้ลคลิก ";
      break;
    case long_click:
      msg_0 = "กดแช่ ";
      break;
  }
  String msg_1 = " (";// สร้างข้อความเพิ่มเติมแสดงจำนวนครั้งที่คลิก
  // แปลงจำนวนครั้งที่คลิกเป็น String
  String msg_2 = String(btn.getNumberOfClicks());
  // ปิดวงเล็บ
  String msg_3 = ")";
  // รวมข้อความทั้งหมดเข้าด้วยกัน
  msg = msg_0 + msg_1 + msg_2 + msg_3;
  // แสดงผลข้อความผ่าน Monitor
  Monitor.println(msg);
}
