// เรียกใช้ไลบรารีสำหรับอุปกรณ์ Modulino
#include "Arduino_Modulino.h"
// ไลบรารีสำหรับแสดงผลผ่าน Monitor
#include "Arduino_RouterBridge.h"
// ------------------ สร้างอ็อบเจ็กต์ ------------------
// สร้างอ็อบเจ็กต์สำหรับเซนเซอร์วัดระยะทาง
ModulinoDistance distance;
// ตัวแปรสำหรับเก็บข้อความที่จะแสดงผล
String msg;

void setup() {
  // เริ่มต้นการสื่อสารกับ Monitor
  Monitor.begin();
  // เริ่มต้นระบบ Modulino
  Modulino.begin();
  // เริ่มต้นการทำงานของเซนเซอร์วัดระยะทาง
  distance.begin();
}

void loop() {
  // ตรวจสอบว่ามีข้อมูลระยะทางใหม่พร้อมให้อ่านหรือไม่
  if (distance.available()) {
    // อ่านค่าระยะทางจากเซนเซอร์
    int measure = distance.get();
    // สร้างข้อความสำหรับแสดงผล
    String msg_1 = "ค่าระยะทาง :";
    String msg_2 = String(measure);
    // รวมข้อความเข้าด้วยกัน
    msg = msg_1 + msg_2;
    // แสดงค่าระยะทางผ่าน Monitor
    Monitor.println(msg);
  }
  // หน่วงเวลาเล็กน้อยเพื่อลดความถี่ในการอ่านค่า
  delay(10);
}
