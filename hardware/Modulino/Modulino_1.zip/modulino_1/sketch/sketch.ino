#include "Arduino_Modulino.h"       // เรียกใช้ไลบรารีสำหรับควบคุมอุปกรณ์ Modulino
#include "Arduino_RouterBridge.h"   // เรียกใช้ไลบรารี RouterBridge เพื่อใช้ Monitor.print() และ Monitor.println()
// Create object instance
ModulinoButtons buttons;            // สร้างอ็อบเจกต์ buttons สำหรับควบคุม Modulino Buttons
void setup() {
  Monitor.begin();                  // เริ่มต้นการสื่อสารผ่าน Monitor เพื่อแสดงข้อความบน Serial Monitor
  Modulino.begin();                 // เริ่มต้นระบบ Modulino
  buttons.begin();                  // เริ่มต้นการทำงานของ Modulino Buttons
  // Function to control the LEDs on top of each button
  buttons.setLeds(false, false, false); // ปิด LED ของปุ่ม A, B และ C ทั้งหมด
}

void loop() {
  // Request new data from the Modulino Buttons
  if (buttons.update()) {           // ตรวจสอบและอัปเดตสถานะปุ่ม หากมีข้อมูลใหม่จะทำงานในบล็อกนี้
    bool a = buttons.isPressed(0);  // ตรวจสอบว่าปุ่ม A (หมายเลข 0) ถูกกดหรือไม่
    bool b = buttons.isPressed(1);  // ตรวจสอบว่าปุ่ม B (หมายเลข 1) ถูกกดหรือไม่
    bool c = buttons.isPressed(2);  // ตรวจสอบว่าปุ่ม C (หมายเลข 2) ถูกกดหรือไม่
    buttons.setLeds(a, b, c);       // เปิดหรือปิด LED ของแต่ละปุ่มตามสถานะการกด
    // Check if any button has been pressed
    if (a) {                        // ถ้าปุ่ม A ถูกกด
      Monitor.println("ปุ่ม A ถูกกด!"); // แสดงข้อความว่า ปุ่ม A ถูกกด
    } 
    
    if (b) {                        // ถ้าปุ่ม B ถูกกด
      Monitor.println("ปุ่ม B ถูกกด!"); // แสดงข้อความว่า ปุ่ม B ถูกกด
    } 
    
    if (c) {                        // ถ้าปุ่ม C ถูกกด
      Monitor.println("ปุ่ม C ถูกกด!"); // แสดงข้อความว่า ปุ่ม C ถูกกด
    }
  }
}