// เรียกใช้ไลบรารีสำหรับอุปกรณ์ Modulino
#include "Arduino_Modulino.h"
// ไลบรารีสำหรับแสดงผลผ่าน Monitor
#include "Arduino_RouterBridge.h"
// สร้างอ็อบเจ็กต์สำหรับเซนเซอร์วัดอุณหภูมิและความชื้น
ModulinoThermo thermo;
// กำหนดค่าเกณฑ์อุณหภูมิ (แจ้งเตือนเมื่อมากกว่า 30°C)
const float TEMP_THRESHOLD = 30.0;
// กำหนดค่าเกณฑ์ความชื้น (แจ้งเตือนเมื่อมากกว่า 70%)
const float HUMIDITY_THRESHOLD = 70.0;
// ตัวแปรเก็บข้อความแสดงผล
String msg, msg_t, msg_h;

void setup(){
  // เริ่มต้นการสื่อสารกับ Monitor
  Monitor.begin();
  // เริ่มต้นระบบ Modulino
  Modulino.begin();
  // เริ่มต้นการทำงานของเซนเซอร์ Thermo
  thermo.begin();
  // แสดงข้อความเมื่อระบบเริ่มทำงาน
  Monitor.println("ระบบตรวจวัดสภาพแวดล้อมเริ่มทำงานแล้ว");
}

void loop(){
  // อ่านค่าอุณหภูมิจากเซนเซอร์ (หน่วย °C)
  float temp = thermo.getTemperature();
  // อ่านค่าความชื้นสัมพัทธ์ (หน่วย %)
  float hum = thermo.getHumidity();
  // ---------------- ตรวจสอบอุณหภูมิ ----------------
  // ถ้าอุณหภูมิสูงกว่าเกณฑ์ที่กำหนด
  if(temp > TEMP_THRESHOLD) {
    String msg_1 = "⚠️ อุณหภูมิสูง: ";
    String msg_2 = String(temp, 2);  // แสดงทศนิยม 2 ตำแหน่ง
    String msg_3 = "°C";
    // รวมข้อความแจ้งเตือน
    msg_t = msg_1 + msg_2 + msg_3;
    // แสดงผลแจ้งเตือน
    Monitor.println(msg_t);
  }
  
  // ---------------- ตรวจสอบความชื้น ----------------
  // ถ้าความชื้นสูงกว่าเกณฑ์ที่กำหนด
  if(hum > HUMIDITY_THRESHOLD) {
    String msg_1 = "⚠️ ความชื้นในอากาศสูง: ";
    String msg_2 = String(hum, 2);  // แสดงทศนิยม 2 ตำแหน่ง
    String msg_3 = "%";
    // รวมข้อความแจ้งเตือน
    msg_h = msg_1 + msg_2 + msg_3;
    // แสดงผลแจ้งเตือน
    Monitor.println(msg_h);
  }
  
  // ---------------- กรณีค่าปกติ ----------------
  // ถ้าอุณหภูมิและความชื้นไม่เกินค่าที่กำหนด
  if(temp <= TEMP_THRESHOLD && hum <= HUMIDITY_THRESHOLD) {
    String msg_1 = "อุณหภูมิ: ";
    String msg_2 = String(temp, 2);
    String msg_3 = "°C, ความชื้น: ";
    String msg_4 = String(hum, 2);
    String msg_5 = "%";
    // รวมข้อความแสดงค่าปกติ
    msg = msg_1 + msg_2 + msg_3 + msg_4 + msg_5;
    // แสดงค่าปกติ
    Monitor.println(msg);
  }
  // หน่วงเวลา 5 วินาที ก่อนอ่านค่ารอบถัดไป
  delay(5000);
}
