// เรียกใช้ไลบรารีสำหรับอุปกรณ์ Modulino
#include "Arduino_Modulino.h"
// ไลบรารีสำหรับใช้ Monitor แสดงผลผ่านคอมพิวเตอร์
#include "Arduino_RouterBridge.h"
// สร้างอ็อบเจ็กต์สำหรับใช้งานโมดูลวัดอุณหภูมิและความชื้น
ModulinoThermo thermo;
// ------------------ ตัวแปร Global ------------------
// เก็บค่าอุณหภูมิ (หน่วยองศาเซลเซียส)
float celsius = 0;
// เก็บค่าความชื้นสัมพัทธ์ (หน่วยเปอร์เซ็นต์)
float humidity = 0;

void setup(){
  // เริ่มต้นการสื่อสารกับ Monitor
  Monitor.begin();
  // เริ่มต้นระบบ Modulino
  Modulino.begin();
  // เริ่มต้นการทำงานของโมดูล Thermo
  thermo.begin();
}

void loop(){
  // อ่านค่าอุณหภูมิจากเซนเซอร์
  celsius = thermo.getTemperature();
  // อ่านค่าความชื้นจากเซนเซอร์
  humidity = thermo.getHumidity();
  // ------------------ สร้างข้อความสำหรับแสดงผล ------------------
  Monitor.println("===============================");
  Monitor.print("อุณหภูมิมีค่าเท่ากับ (องศาเซลเซียส) :");
  String msg_cel = String(celsius);
  Monitor.println(msg_cel);
  Monitor.print("ความชื้นมีค่าเท่ากับ (เปอร์เซ็นต์) :");
  String msg_hum = String(humidity);
  Monitor.println(msg_hum);
  
  delay(1000);
}
