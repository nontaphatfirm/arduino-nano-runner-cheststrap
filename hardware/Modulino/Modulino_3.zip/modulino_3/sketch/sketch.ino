#include "Arduino_Modulino.h"   // เรียกใช้ไลบรารีสำหรับควบคุมอุปกรณ์ Modulino
ModulinoPixels leds;            // สร้างอ็อบเจกต์ leds สำหรับควบคุม Modulino Pixels
void setup(){
  Modulino.begin();             // เริ่มต้นระบบ Modulino
  leds.begin();                 // เริ่มต้นการทำงานของ Modulino Pixels
}

void loop(){
    leds.set(0, BLUE, 255);     // กำหนดให้ LED ดวงที่ 0 แสดงสีฟ้า (BLUE) ด้วยความสว่างระดับ 255
    leds.show();                // ส่งค่าที่ตั้งไว้ไปแสดงผลบน LED
    delay(500);// หน่วงเวลา 500 มิลลิวินาที (0.5 วินาที)

    leds.set(0, BLUE, 0);     // กำหนดให้ LED ดวงที่ 0 แสดงสีฟ้า (BLUE) ด้วยความสว่างระดับ 0
    leds.show();                // ส่งค่าที่ตั้งไว้ไปแสดงผลบน LED
    delay(500);// หน่วงเวลา 500 มิลลิวินาที (0.5 วินาที)
}