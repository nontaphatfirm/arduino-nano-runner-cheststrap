// เรียกใช้ไลบรารีสำหรับอุปกรณ์ Modulino
#include "Arduino_Modulino.h"
// ไลบรารีสำหรับแสดงผลผ่าน Monitor
#include <Arduino_RouterBridge.h>
// ------------------ สร้างอ็อบเจ็กต์ ------------------
// สร้างอ็อบเจ็กต์สำหรับโมดูลตรวจจับการเคลื่อนไหว (Accelerometer + Gyroscope)
ModulinoMovement movement;
// ตัวแปรเก็บค่า Acceleration (ความเร่ง) แกน X, Y, Z
float x, y, z;
// ตัวแปรเก็บค่า Gyroscope (การหมุน) roll, pitch, yaw
float roll, pitch, yaw;
// ตัวแปรสำหรับเก็บข้อความที่จะแสดงผล
String msg;

void setup() {
  // เริ่มต้นการสื่อสารกับ Monitor
  Monitor.begin();
  // เริ่มต้นระบบ Modulino (I2C Communication)
  Modulino.begin();
  // เริ่มต้นการทำงานของเซนเซอร์ตรวจจับการเคลื่อนไหว
  movement.begin();
}

void loop() {
  // อัปเดตข้อมูลใหม่จากเซนเซอร์
  movement.update();
  // ------------------ อ่านค่า Acceleration ------------------
  // อ่านค่าความเร่งในแต่ละแกน
  x = movement.getX();
  y = movement.getY();
  z = movement.getZ();
  // ------------------ อ่านค่า Gyroscope ------------------
  // อ่านค่าการหมุน (มุมเอียง)
  roll = movement.getRoll();
  pitch = movement.getPitch();
  yaw = movement.getYaw();
  // ------------------ สร้างข้อความแสดงค่า Acceleration ------------------
  String msg_0 = "ค่าของ Acceleration: ";
  String msg_1 = String(x, 3);   // แสดงทศนิยม 3 ตำแหน่ง
  String msg_2 = ", ";
  String msg_3 = String(y, 3);
  String msg_4 = ", ";
  String msg_5 = String(z, 3);
  String msg_6 = ", ";
  // ตัวคั่นระหว่าง Acceleration และ Gyroscope
  String msg_7 = " | ค่าของ Gyroscope: ";
  // ------------------ สร้างข้อความแสดงค่า Gyroscope ------------------
  String msg_8 = String(roll, 1);   // แสดงทศนิยม 1 ตำแหน่ง
  String msg_9 = ", ";
  String msg_10 = String(pitch, 1);
  String msg_11 = ", ";
  String msg_12 = String(yaw, 1);
  // รวมข้อความทั้งหมดเข้าด้วยกัน
  msg = msg_0 + msg_1 + msg_2 + msg_3 + msg_4 + msg_5 + msg_6 
        + msg_7 + msg_8 + msg_9 + msg_10 + msg_11 + msg_12;
  // แสดงผลผ่าน Monitor
  Monitor.println(msg);
  // หน่วงเวลา 200 มิลลิวินาที (อัปเดตประมาณ 5 ครั้งต่อวินาที)
  delay(200);
}
