// เรียกใช้ไลบรารีสำหรับควบคุม Modulino
#include "Arduino_Modulino.h"
// สร้างอ็อบเจ็กต์ควบคุม Modulino Pixels (LED 8 ดวง)
ModulinoPixels leds;
// กำหนดจำนวน LED ทั้งหมด
const int NUM_LEDS = 8;

void setup() {
  // เริ่มต้นระบบ Modulino
  Modulino.begin();
  // เริ่มต้นโมดูล LED
  leds.begin();
}
// ===========================
// LOOP หลัก
// ===========================
void loop() {
  // เล่นเอฟเฟกต์สายรุ้ง 50 รอบ
  for (int i = 0; i < 50; i++) {
    rainbowCycle();
    delay(100);
  }
  // เล่นเอฟเฟกต์หายใจ 100 รอบ
  for (int i = 0; i < 100; i++) {
    breathingEffect();
    delay(30);
  }
  // เล่นเอฟเฟกต์ไฟวิ่ง 30 รอบ
  for (int i = 0; i < 30; i++) {
    chaseEffect();
    delay(80);
  }
}
// ===========================
// เอฟเฟกต์ที่ 1: Rainbow Cycle
// ===========================
void rainbowCycle() {
  // ตัวแปร static จะจำค่าระหว่างรอบ loop
  static int offset = 0;
  // วนลูปทุก LED
  for (int i = 0; i < NUM_LEDS; i++) {
    // คำนวณตำแหน่งสีแบบเลื่อนหมุน
    int colorIndex = (i + offset) % NUM_LEDS;
    // เนื่องจากไลบรารีรองรับแค่สีสำเร็จรูป
    // จึง map index ให้ใกล้เคียงสีรุ้ง
    switch(colorIndex) {
      case 0:
      case 7:
        leds.set(i, RED, 50);
        break;
      case 1:
      case 2:
        leds.set(i, GREEN, 50);
        break;
      case 3:
      case 4:
        leds.set(i, BLUE, 50);
        break;
      case 5:
      case 6:
        leds.set(i, VIOLET, 50);
        break;
    }
  }
  // แสดงผลจริง
  leds.show();
  // เลื่อนตำแหน่งสีในรอบถัดไป
  offset = (offset + 1) % NUM_LEDS;
}
// ===========================
// เอฟเฟกต์ที่ 2: Breathing Effect
// ===========================
void breathingEffect() {
  // brightness และ direction จำค่าระหว่างรอบ
  static int brightness = 0;
  static int direction = 1;
  // เพิ่มหรือลดความสว่างทีละ 5
  brightness += direction * 5;
  // ถ้าสว่างสุดหรือมืดสุด ให้กลับทิศ
  if (brightness >= 100 || brightness <= 0) {
    direction = -direction;
  }
  // ตั้งค่า LED ทุกดวงเป็นสีน้ำเงิน
  // แต่ปรับระดับความสว่างตาม brightness
  for (int i = 0; i < NUM_LEDS; i++) {
    leds.set(i, BLUE, brightness);
  }
  // แสดงผลจริง
  leds.show();
}
// ===========================
// เอฟเฟกต์ที่ 3: Chase Effect (ไฟวิ่ง)
// ===========================
void chaseEffect() {
  static int position = 0;
  // ปิดไฟทุกดวงก่อน
  for (int i = 0; i < NUM_LEDS; i++) {
    leds.set(i, WHITE, 0);
  }
  // เปิดไฟดวงปัจจุบันสว่างสุด
  leds.set(position, WHITE, 100);
  // ทำหางไฟ (ความสว่างต่ำกว่า)
  if (position > 0) {
    leds.set(position - 1, WHITE, 30);
  } else {
    leds.set(NUM_LEDS - 1, WHITE, 30);
  }
  // แสดงผลจริง
  leds.show();
  // เลื่อนตำแหน่งไปดวงถัดไป
  position = (position + 1) % NUM_LEDS;
}

