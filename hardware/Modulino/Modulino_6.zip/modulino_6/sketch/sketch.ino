// เรียกใช้ไลบรารีสำหรับอุปกรณ์ Modulino
#include "Arduino_Modulino.h"
// เรียกใช้ RouterBridge สำหรับใช้ Monitor แสดงผล
#include "Arduino_RouterBridge.h"
// สร้างอ็อบเจ็กต์สำหรับควบคุม Knob (Rotary Encoder)
ModulinoKnob knob;
// ================== การตั้งค่าเมนู ==================
// จำนวนรายการเมนูทั้งหมด
const int MENU_ITEMS = 5;
// สร้างอาร์เรย์เก็บชื่อเมนู
String menuOptions[] = {"ตั้งค่า", "หน้าจอ", "เสียง", "เครือข่าย", "ออก"};
// เก็บตำแหน่งเมนูที่กำลังถูกเลือก
int currentSelection = 0;
// เก็บค่าตำแหน่งก่อนหน้าของ Knob
int lastPosition = 0;
// เก็บสถานะปุ่มก่อนหน้า (ใช้ตรวจจับการกดแบบปล่อยปุ่ม)
bool lastButtonState = false;

void setup() {
  // เริ่มการสื่อสารกับ Monitor
  Monitor.begin();
  // เริ่มต้นระบบ Modulino
  Modulino.begin();
  // เริ่มต้น Knob
  knob.begin();
  // กำหนดค่าเริ่มต้นของ encoder เป็น 0
  knob.set(0);
  lastPosition = 0;
  // แสดงเมนูครั้งแรก
  displayMenu();
}
// ================== วนลูปหลัก ==================
void loop() {
  // อ่านค่าตำแหน่งปัจจุบันของ Knob
  int currentPosition = knob.get();
  // อ่านสถานะปุ่ม (true = กดอยู่)
  bool buttonPressed = knob.isPressed();
  // คำนวณว่าหมุนไปกี่สเต็ปจากรอบก่อน
  int rotation = currentPosition - lastPosition;
  // ===== ตรวจจับการหมุน =====
  if (rotation != 0) {
    // ถ้าหมุนตามเข็ม (ค่ามากขึ้น)
    if (rotation > 0) {
      currentSelection++;
      // ถ้าเกินจำนวนเมนู → กลับไปข้อแรก (วนลูป)
      if (currentSelection >= MENU_ITEMS) {
        currentSelection = 0;
      }
    } else {  // ถ้าหมุนทวนเข็ม
      currentSelection--;
      // ถ้าต่ำกว่า 0 → ไปข้อสุดท้าย
      if (currentSelection < 0) {
        currentSelection = MENU_ITEMS - 1;
      }
    }
    // อัปเดตตำแหน่งล่าสุด
    lastPosition = currentPosition;
    // แสดงเมนูใหม่
    displayMenu();
  }
  // ===== ตรวจจับการกดปุ่ม =====
  // ตรวจตอน "ปล่อยปุ่ม" เพื่อป้องกันการเรียกซ้ำหลายครั้ง
  if (!buttonPressed && lastButtonState) {
    selectMenuItem();
  }
  // อัปเดตสถานะปุ่มล่าสุด
  lastButtonState = buttonPressed;
  // หน่วงเล็กน้อยช่วยลดอาการสั่นของสัญญาณ (debounce)
  delay(50);
}

// ================== ฟังก์ชันแสดงเมนู ==================
void displayMenu() {
  Monitor.println("\n======= เมนู =======");
  // วนลูปแสดงรายการเมนูทั้งหมด
  for (int i = 0; i < MENU_ITEMS; i++) {
    // ถ้ารายการนี้คือรายการที่ถูกเลือก
    if (i == currentSelection) {
      Monitor.print("> ");  // แสดงเครื่องหมาย >
    } else {
      Monitor.print("  ");  // เว้นวรรคปกติ
    }
    // แสดงชื่อเมนู
    Monitor.println(menuOptions[i]);
  }
  Monitor.println("==================");
  Monitor.println("หมุนเพื่อเลือกเมนู, กดเพื่อตกลง");
}

// ================== ฟังก์ชันเมื่อเลือกเมนู ==================
void selectMenuItem() {
  Monitor.print("\n✓ เลือกแล้ว: ");
  Monitor.println(menuOptions[currentSelection]);
  // ตรวจสอบว่าผู้ใช้เลือกเมนูข้อไหน
  switch(currentSelection) {
    case 0:
      Monitor.println("กำลังเปิดการตั้งค่า...");
      break;
    case 1:
      Monitor.println("กำลังเปิดการตั้งค่าหน้าจอ...");
      break;
    case 2:
      Monitor.println("กำลังเปิดเพื่อจัดการระบบเสียง...");
      break;
    case 3:
      Monitor.println("กำลังเปิดเพื่อตั้งค่าเครือข่าย...");
      break;
    case 4:
      Monitor.println("ออกจากเมนู...");
      break;
  }
  // หน่วงเวลาเพื่อให้ผู้ใช้เห็นข้อความ
  delay(1000);
  // กลับมาแสดงเมนูอีกครั้ง
  displayMenu();
}
