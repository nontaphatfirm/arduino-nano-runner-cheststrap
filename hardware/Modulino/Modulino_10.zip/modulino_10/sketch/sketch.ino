// เรียกใช้ไลบรารีสำหรับอุปกรณ์ Modulino
#include "Arduino_Modulino.h"
// ไลบรารีสำหรับแสดงผลผ่าน Monitor
#include "Arduino_RouterBridge.h"
// ------------------ สร้างอ็อบเจ็กต์ ------------------
// สร้างอ็อบเจ็กต์สำหรับเซนเซอร์วัดระยะทาง
ModulinoDistance distance;
// ------------------ กำหนดช่วงระยะ (หน่วยเซนติเมตร) ------------------
// ระยะอันตรายมาก (น้อยกว่า 10 ซม.)
const int DANGER_ZONE = 10;
// ระยะเตือน (10–30 ซม.)
const int WARNING_ZONE = 30;
// ระยะควรระวัง (30–50 ซม.)
const int CAUTION_ZONE = 50;
// ระยะปลอดภัย (50–100 ซม.)
const int SAFE_ZONE = 100;
// ตัวแปรเก็บข้อความที่จะแสดงผล
String msg;

void setup() {
  // เริ่มต้นการสื่อสารกับ Monitor
  Monitor.begin();
  // เริ่มต้นระบบ Modulino
  Modulino.begin();
  // เริ่มต้นการทำงานของเซนเซอร์วัดระยะทาง
  distance.begin();
}

void loop() {
  // ตรวจสอบว่ามีข้อมูลระยะทางใหม่หรือไม่
  if (distance.available()) {
    // อ่านค่าระยะทางจากเซนเซอร์ (หน่วยเซนติเมตร)
    int measure = distance.get();
    // ------------------ ตรวจสอบช่วงระยะ ------------------
    // ถ้าระยะน้อยกว่า 10 ซม. (อันตรายมาก)
    if (measure < DANGER_ZONE) {
      String msg_1 = "🔴 หยุด! ระยะทาง: ";
      String msg_2 = String(measure);
      String msg_3 = " เซ็นติเมตร - ใกล้แบบนี้ ชนแน่นอน!";
      // รวมข้อความ
      msg = msg_1 + msg_2 + msg_3;
      // แสดงผล
      Monitor.println(msg);
    }
    // ถ้าระยะอยู่ระหว่าง 10–30 ซม. (เตือน)
    else if (measure < WARNING_ZONE) {
      String msg_1 = "🟠 เตือน - ระยะทาง: ";
      String msg_2 = String(measure);
      String msg_3 = " เซ็นติเมตร - ใกล้วัตถุมาก";
      msg = msg_1 + msg_2 + msg_3;
      Monitor.println(msg);
    }
    // ถ้าระยะอยู่ระหว่าง 30–50 ซม. (ควรระวัง)
    else if (measure < CAUTION_ZONE) {
      String msg_1 = "🟡 ระวัง - ระยะทาง: ";
      String msg_2 = String(measure);
      String msg_3 = " เซ็นติเมตร - มีวัตถุขวางทาง";
      msg = msg_1 + msg_2 + msg_3;
      Monitor.println(msg);
    }
    // ถ้าระยะอยู่ระหว่าง 50–100 ซม. (ปลอดภัย)
    else if (measure < SAFE_ZONE) {
      String msg_1 = "🟢 ระยะปลอดภัย - ระยะทาง: ";
      String msg_2 = String(measure);
      String msg_3 = " เซ็นติเมตร - ทางโล่ง";
      msg = msg_1 + msg_2 + msg_3;
      Monitor.println(msg);
    }
    // ถ้ามากกว่า 100 ซม. (ไม่มีสิ่งกีดขวางใกล้เคียง)
    else {
      String msg_1 = "✓ ไม่มีสิ่งกีดขวาง - ระยะทาง: ";
      String msg_2 = String(measure);
      String msg_3 = " เซ็นติเมตร";
      msg = msg_1 + msg_2 + msg_3;
      Monitor.println(msg);
    }
  }
  // หน่วงเวลา 100 มิลลิวินาที (อัปเดตประมาณ 10 ครั้งต่อวินาที)
  delay(100);
}
