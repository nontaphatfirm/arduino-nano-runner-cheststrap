// เรียกใช้ไลบรารีสำหรับอุปกรณ์ Modulino
#include "Arduino_Modulino.h"
// ไลบรารีสำหรับแสดงผลผ่าน Monitor
#include <Arduino_RouterBridge.h>
// ------------------ สร้างอ็อบเจ็กต์ ------------------
// โมดูลตรวจจับการเคลื่อนไหว (Accelerometer + Gyroscope)
ModulinoMovement movement;
// ------------------ ค่ากำหนดเกณฑ์การตรวจจับ ------------------
// ค่าเกณฑ์ความเร่ง (หน่วย g)
const float MOTION_THRESHOLD = 0.15;
// ค่าเกณฑ์การหมุน (องศาต่อวินาที)
const float ROTATION_THRESHOLD = 20.0;
// ------------------ ตัวแปรสำหรับการปรับเทียบ (Calibration) ------------------
// ค่าเริ่มต้นของแกน X, Y, Z (คาดว่าเมื่อวางราบ Z ≈ 1g)
float baseX = 0, baseY = 0, baseZ = 1.0;
// ค่าเริ่มต้นของมุม Roll, Pitch, Yaw
float baseRoll = 0, basePitch = 0, baseYaw = 0;
// สถานะว่าปรับเทียบแล้วหรือยัง
bool isCalibrated = false;
// ------------------ ตัวแปรติดตามสถานะการเคลื่อนไหว ------------------
// ตัวแปรเก็บสถานะว่าขณะนี้มีการเคลื่อนไหวอยู่หรือไม่
bool inMotion = false;
// ตัวแปรเก็บเวลาเริ่มต้นของการเคลื่อนไหว
unsigned long motionStartTime = 0;
// ตัวแปรเก็บเวลาเริ่มต้นของการอยู่นิ่ง
unsigned long stillStartTime = 0;
// ระยะเวลาที่ต้องนิ่ง (2 วินาที) เพื่อถือว่าหยุดเคลื่อนไหว
const unsigned long STILL_TIMEOUT = 2000;

void setup() {
  // เริ่มต้นการสื่อสารผ่าน Monitor
  Monitor.begin();
  // เริ่มต้นระบบ Modulino
  Modulino.begin();
  // เริ่มต้นโมดูลตรวจจับการเคลื่อนไหว
  movement.begin();
  // แสดงข้อความเริ่มต้นระบบ
  Monitor.println("ระบบตรวจจับการเคลื่อนไหว");
  // แสดงเส้นแบ่งข้อความ
  Monitor.println("======================");
  // แจ้งให้ผู้ใช้วางอุปกรณ์นิ่งเพื่อปรับเทียบ
  Monitor.println("กรุณาวางอุปกรณ์ให้นิ่งเพื่อทำการปรับเทียบ (คาลิเบรต)...");
  // หน่วงเวลา 2 วินาที เพื่อให้ผู้ใช้มีเวลาวางอุปกรณ์
  delay(2000);
  // เรียกฟังก์ชันสำหรับปรับเทียบเซนเซอร์
  calibrateSensor();
}

// ------------------ ลูปหลัก ------------------

void loop() {
  // ทำงานเฉพาะเมื่อปรับเทียบเซนเซอร์เรียบร้อยแล้ว
  if (isCalibrated) {
    // เรียกฟังก์ชันตรวจจับการเคลื่อนไหว
    detectMotion();
    // หน่วงเวลา 50 ms (ประมาณ 20 ครั้งต่อวินาที)
    delay(50);
  }
}

// ------------------ ฟังก์ชันปรับเทียบเซนเซอร์ ------------------

void calibrateSensor() {
  // จำนวนตัวอย่างที่ใช้ในการเฉลี่ยค่า
  const int samples = 50;
  // ตัวแปรสำหรับเก็บผลรวมค่าต่าง ๆ
  float sumX = 0, sumY = 0, sumZ = 0;
  float sumRoll = 0, sumPitch = 0, sumYaw = 0;
  // วนลูปเก็บข้อมูลหลายครั้งเพื่อนำมาเฉลี่ย
  for (int i = 0; i < samples; i++) {
    // อัปเดตค่าจากเซนเซอร์
    movement.update();
    // รวมค่าความเร่งแกน X
    sumX += movement.getX();
    // รวมค่าความเร่งแกน Y
    sumY += movement.getY();
    // รวมค่าความเร่งแกน Z
    sumZ += movement.getZ();
    // รวมค่ามุม Roll
    sumRoll += movement.getRoll();
    // รวมค่ามุม Pitch
    sumPitch += movement.getPitch();
    // รวมค่ามุม Yaw
    sumYaw += movement.getYaw();
    // หน่วงเวลาเล็กน้อยก่อนอ่านค่ารอบถัดไป
    delay(20);
  }

  // คำนวณค่าเฉลี่ยของแกน X
  baseX = sumX / samples;
  // คำนวณค่าเฉลี่ยของแกน Y
  baseY = sumY / samples;
  // คำนวณค่าเฉลี่ยของแกน Z
  baseZ = sumZ / samples;
  // คำนวณค่าเฉลี่ยของมุม Roll
  baseRoll = sumRoll / samples;
  // คำนวณค่าเฉลี่ยของมุม Pitch
  basePitch = sumPitch / samples;
  // คำนวณค่าเฉลี่ยของมุม Yaw
  baseYaw = sumYaw / samples;
  // ตั้งสถานะว่าปรับเทียบเสร็จแล้ว
  isCalibrated = true;
  // แสดงข้อความว่าปรับเทียบสำเร็จ
  Monitor.println("✓ การปรับเทียบ(คาลิเบรต)เสร็จสมบูรณ์แล้ว!");
  // เว้นบรรทัด
  Monitor.println();
}

// ------------------ ฟังก์ชันตรวจจับการเคลื่อนไหว ------------------

void detectMotion() {
  // อัปเดตข้อมูลจากเซนเซอร์
  movement.update();
  // คำนวณค่าความแตกต่างของแกน X จากค่า baseline
  float deltaX = abs(movement.getX() - baseX);
  // คำนวณค่าความแตกต่างของแกน Y จากค่า baseline
  float deltaY = abs(movement.getY() - baseY);
  // คำนวณค่าความแตกต่างของแกน Z จากค่า baseline
  float deltaZ = abs(movement.getZ() - baseZ);
  // คำนวณค่าความแตกต่างของ Roll จากค่า baseline
  float deltaRoll = abs(movement.getRoll() - baseRoll);
  // คำนวณค่าความแตกต่างของ Pitch จากค่า baseline
  float deltaPitch = abs(movement.getPitch() - basePitch);
  // คำนวณค่าความแตกต่างของ Yaw จากค่า baseline
  float deltaYaw = abs(movement.getYaw() - baseYaw);
  // ตรวจสอบว่าค่าใดเกินเกณฑ์หรือไม่
  bool motionDetected = (deltaX > MOTION_THRESHOLD || 
                         deltaY > MOTION_THRESHOLD || 
                         deltaZ > MOTION_THRESHOLD ||
                         deltaRoll > ROTATION_THRESHOLD ||
                         deltaPitch > ROTATION_THRESHOLD ||
                         deltaYaw > ROTATION_THRESHOLD);

  // ------------------ State Machine การตรวจจับ ------------------
  // กรณีเริ่มตรวจพบการเคลื่อนไหวใหม่
  if (motionDetected && !inMotion) {
    // ตั้งสถานะว่าเริ่มเคลื่อนไหวแล้ว
    inMotion = true;
    // บันทึกเวลาเริ่มต้นการเคลื่อนไหว
    motionStartTime = millis();
    // แสดงข้อความตรวจพบการเคลื่อนไหว
    Monitor.println("🏃 ตรวจพบการเคลื่อนไหว!");
    // ตรวจสอบว่าเป็นการหมุนหรือไม่
    if (deltaRoll > ROTATION_THRESHOLD || deltaPitch > ROTATION_THRESHOLD) {
      // แสดงประเภทการเคลื่อนไหวเป็นการหมุน
      Monitor.println("   ประเภท: การหมุน");
    }
    // ตรวจสอบว่าเป็นการเคลื่อนที่เชิงเส้นหรือไม่
    if (deltaX > MOTION_THRESHOLD || deltaY > MOTION_THRESHOLD) {
      // แสดงประเภทการเคลื่อนไหวเชิงเส้น
      Monitor.println("   ประเภท: การเคลื่อนที่เชิงเส้น");
    }
    // ตรวจสอบว่าเป็นการเคลื่อนที่แนวตั้งหรือไม่
    if (deltaZ > MOTION_THRESHOLD * 2) {
      // แสดงประเภทการเคลื่อนไหวแนวตั้ง
      Monitor.println("   ประเภท: การเคลื่อนที่ในแนวตั้ง");
    }
  }
  // กรณีไม่มีการเคลื่อนไหว แต่ก่อนหน้านี้กำลังเคลื่อนไหวอยู่
  else if (!motionDetected && inMotion) {
    // ถ้ายังไม่เริ่มจับเวลาความนิ่ง
    if (stillStartTime == 0) {
      // บันทึกเวลาเริ่มนิ่ง
      stillStartTime = millis();
    }
    // ถ้านิ่งเกินเวลาที่กำหนด
    else if (millis() - stillStartTime > STILL_TIMEOUT) {
      // ตั้งสถานะว่าไม่มีการเคลื่อนไหวแล้ว
      inMotion = false;
      // คำนวณระยะเวลาการเคลื่อนไหว (วินาที)
      unsigned long duration = (millis() - motionStartTime) / 1000;
      // แสดงข้อความว่าหยุดเคลื่อนไหวแล้ว
      Monitor.print("✋ การเคลื่อนไหวหยุดลง ระยะเวลา: ");
      // แสดงจำนวนวินาทีที่เคลื่อนไหว
      Monitor.print(duration);
      // แสดงหน่วยวินาที
      Monitor.println(" วินาที");
      // รีเซ็ตตัวจับเวลาความนิ่ง
      stillStartTime = 0;
    }
  }
  // กรณียังมีการเคลื่อนไหวต่อเนื่อง
  else if (motionDetected && inMotion) {
    // รีเซ็ตตัวจับเวลาความนิ่ง
    stillStartTime = 0;
  }
}